import React, { useState } from "react";
import { NavLink } from "react-router-dom";
import {
  Card,
  CardContent,
  TextField,
  Button,
  Typography,
  Paper,
  Container,
} from "@mui/material";
import Grid from "@mui/material/Grid2";

function SignUp() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    password_confirmation: "",
  });

  const [error, setError] = useState("");

  const handleChange = (e) => {
    const { id, value } = e.target;
    setFormData((prev) => ({ ...prev, [id]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (formData.name === "") {
      setError("Name is required!");
    } else if (formData.email === "") {
      setError("E-mail is required!");
    } else if (formData.password === "") {
      setError("Please Set Your Password!");
    } else if (formData.password !== formData.password_confirmation) {
      setError("Passwords do not match!");
    } else {
      setError("");
    }
      let fdata = {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(formData),
      };

      fetch("http://127.0.0.1:8000/api/v1/register", fdata)
        .then((res) => res.json())
        .then((json) => console.log(json));

    // .then((res) => {
    //   res.json();
    //   if (res.ok) {
    //     console.log(res);
    //     console.log(res.body);
    //     alert("Registered");
    //   } else {
    //     console.log(res);
    //   }
    // })
    // .catch((error) => {
    //   alert("Registration Failed " + error.message);
    // });
  };

  return (
    <Container
      container
      sx={{
        alignContent: "center",
        justifyContent: "center",
        height: "100vh",
      }}
    >
      <Paper elevation={3} sx={{ padding: 1.5 }}>
        <Grid container spacing={2}>
          <Grid item size={{ xs: 12, lg: 5 }}>
            <Card
              sx={{
                display: "flex",
                flexDirection: "column",
                justifyContent: "center",
                alignItems: "center",
                boxShadow: 0,
              }}
              component="form"
              noValidate
              autoComplete="on"
              onSubmit={handleSubmit}
            >
              <CardContent
                sx={{
                  display: "flex",
                  flexDirection: "column",
                  justifyContent: "center",
                  alignItems: "center",
                  gap: 1.5,
                }}
              >
                <Typography variant="h5" component="div">
                  SignUp
                </Typography>
                <TextField
                  required
                  id="name"
                  label="Name"
                  size="small"
                  value={formData.name}
                  onChange={handleChange}
                />
                <TextField
                  required
                  id="email"
                  label="E-mail"
                  size="small"
                  type="email"
                  value={formData.email}
                  onChange={handleChange}
                />
                <TextField
                  required
                  id="password"
                  label="Password"
                  type="password"
                  size="small"
                  autoComplete="current-password"
                  value={formData.password}
                  onChange={handleChange}
                />
                <TextField
                  required
                  id="password_confirmation"
                  label="Confirm Password"
                  type="password"
                  size="small"
                  autoComplete="current-password"
                  value={formData.password_confirmation}
                  onChange={handleChange}
                />
              </CardContent>
              {error && (
                <Card sx={{ color: "red", minWidth: 275 }}>{error}</Card>
              )}
              <Button
                type="submit"
                variant="contained"
                sx={{ m: 1, padding: "6px 60px" }}
              >
                GET STARTED
              </Button>
              <Typography sx={{ padding: "16px" }}>
                Already have an account?{" "}
                <NavLink className="navbar-brand" to="/Login">
                  LogIn
                </NavLink>
              </Typography>
            </Card>
          </Grid>
          <Grid
            item
            size={7}
            sx={{
              background: "#a472fd",
              borderRadius: 1.5,
            }}
          ></Grid>
        </Grid>
      </Paper>
    </Container>
  );
}

export default SignUp;
