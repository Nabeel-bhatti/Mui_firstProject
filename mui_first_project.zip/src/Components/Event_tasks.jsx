import React from 'react'

function EventTasks() {
  return (
    <div>EventTasks</div>
  )
}

export default EventTasks