import React from 'react'

function Performance() {
  return (
    <div>Performance</div>
  )
}

export default Performance