import React from 'react'

function TimeRange() {
  return (
    <div>TimeRange</div>
  )
}

export default TimeRange