import React from 'react'

function Upload() {
  return (
    <div>Upload</div>
  )
}

export default Upload