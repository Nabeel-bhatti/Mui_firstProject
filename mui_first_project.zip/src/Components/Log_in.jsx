import React, { useState } from "react";
import { NavLink, useNavigate } from "react-router-dom";
import {
  Card,
  CardContent,
  TextField,
  Button,
  Typography,
  Paper,
  Container,
} from "@mui/material";
import Grid from "@mui/material/Grid2";

function LogIn() {
  let navigate = useNavigate();

  const [data, setData] = useState({
    email: "",
    password: "",
  });
  const [error, setError] = useState("");

  const handleChange = (e) => {
    const { id, value } = e.target;
    setData((prev) => ({ ...prev, [id]: value }));
  };

  async function handleSubmit(e) {
    e.preventDefault();
    if (data.email === "") {
      setError("Please enter Your E-mail!");
    } else if (data.password === "") {
      setError("Please enter Your Password!");
    } else {
      setError("");
    }
    console.log(data);

    // let result = await fetch("http://127.0.0.1:8000/api/v1/login", {
    //   method: "POST",
    //   headers: { "content-type": "application/json" },
    //   body: JSON.stringify(data),
    // });
    // result = await result.json();
    // localStorage.setItem("Bdata", JSON.stringify(result));
    // alert(result.message);
    // // alert(result.data.name);
    // // alert(result.data.token);
    // if (result) {
    //   return navigate("/");
    // } else if (result.data?.token) {
    //   navigate("/login");
    // }

    try {
      let result = await fetch("http://127.0.0.1:8000/api/v1/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      
      result = await result.json();

      if (result.data?.token) {
        localStorage.setItem("Bdata", JSON.stringify(result));
        alert(result.message);
        return navigate("/");
      } else {
        alert("Invalid credentials.");
        return navigate("/login");
      }
    } catch (error) {
      console.error("An error occurred:", error);
      alert("Invalid credentials.");
    }
  }
  return (
    <Container
      container
      sx={{
        alignContent: "center",
        justifyContent: "center",
        height: "100vh",
      }}
    >
      <Paper elevation={3} sx={{ padding: 1.5 }}>
        <Grid container spacing={2}>
          <Grid item size={{ xs: 12, lg: 5 }}>
            <Card
              sx={{
                display: "flex",
                flexDirection: "column",
                justifyContent: "center",
                alignItems: "center",
                boxShadow: 0,
              }}
              component="form"
              noValidate
              autoComplete="on"
              onSubmit={handleSubmit}
            >
              <CardContent
                sx={{
                  width: "full",
                  display: "flex",
                  flexDirection: "column",
                  justifyContent: "center",
                  alignItems: "center",
                  gap: 1.5,
                }}
              >
                <Typography variant="h5" component="div">
                  LogIn
                </Typography>

                <TextField
                  required
                  id="email"
                  label="E-mail"
                  size="small"
                  type="email"
                  value={data.email}
                  onChange={handleChange}
                />
                <TextField
                  required
                  id="password"
                  label="Password"
                  type="password"
                  size="small"
                  autoComplete="current-password"
                  value={data.password}
                  onChange={handleChange}
                />
              </CardContent>
              {error && (
                <Card sx={{ color: "red", minWidth: 275 }}>{error}</Card>
              )}
              <Button
                type="submit"
                variant="contained"
                sx={{ m: 1, padding: "6px 90px" }}
              >
                LOGIN
              </Button>
              <Typography sx={{ padding: "16px" }}>
                Don't have an account?{" "}
                <NavLink className="navbar-brand" to="/signup">
                  SignUp
                </NavLink>
              </Typography>
            </Card>
          </Grid>
          <Grid
            item
            size={7}
            sx={{
              background: "#a472fd",
              borderRadius: 1.5,
            }}
          ></Grid>
        </Grid>
      </Paper>
    </Container>
  );
}

export default LogIn;
