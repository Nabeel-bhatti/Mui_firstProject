import React from 'react'

function Competition() {
  return (
    <div>Competition</div>
  )
}

export default Competition