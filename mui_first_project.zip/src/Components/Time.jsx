import React from 'react'

function Time() {
  return (
    <div>Time</div>
  )
}

export default Time